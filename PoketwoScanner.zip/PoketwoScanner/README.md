# PoketwoScaner

## Steps
- Download the pokemon images and put them into ./data/images/ dir.
- Download pokelist.csv and put it into ./
- Get your Discord Bot TOKEN and invite it into your guild.
- Get your Discord Guild ID.

### The programs was product with AI help.
